# Installation

npm install

---

# Start

nodemon index.js

---
